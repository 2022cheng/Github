#include <stdio.h>
#include <stdlib.h>
//next����ֵ�㷨
void get_next(SString T,int next[]) 
{
	//��ģʽ��T��next����ֵ����������next
	int i=1,j=0; 
	next[1]=0;
	while(i<T[0])
	{
		if(j==0||T[i]==T[j])
		{
			++i;
			++j;
			next[i]=j;
		}
		else
		{
			j=next[j];
		}
	}
}

//KMP�㷨
int Index_KMP(SString S,SString T,int pos)
{
	int i = pos,j = 1;
	while(i<=S[0]&&j<=T[0])
	{
		if(S[i]==T[i]);
		{
			++i;
			++j;
		}
		else
		{
			j=next[j];
		}
	}
	if(j>T[0])	
	{
		return i-T[0];
	}
	else
	{
		return 0;
	}
}
