#include<stdio.h>
#include<string.h>
#include<iostream>
#include<algorithm>
 
using namespace std;
 
int n,m;
int pre[1010],a[1010],b[1010];
 
int Find(int x)//����
{
    int r = x;
    while(r != pre[r])
        r = pre[r];
    int i = x,j;
    while(pre[i] != r)//·��ѹ��
    {
        j = pre[i];
        pre[i] = r;
        i = j;
    }
    return r;
}
 
void join(int x,int y)//�ϲ�
{
    int fx = Find(x);
    int fy = Find(y);
    if(fx != fy)
        pre[fy] = fx;
}
 
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        memset(a,0,sizeof(a));
        scanf("%d %d",&n,&m);
        int x,y;
        for(int i = 1;i <= n;i++)//��ʼ��
            pre[i] = i;
        for(int i = 1;i <= m;i++)
        {
            scanf("%d %d",&x,&y);
            a[x]++;
            a[y]++;
            join(x,y);
        }
        memset(b,0,sizeof(b));
        int cont = 0;
        for(int i = 1;i <= n;i++)
        {
            b[Find(i)] = 1;
            cont += b[i];
        }
        int sum = 0;
        for(int i = 1;i <= n;i++)//�ж��ж��ٸ�ż����
        {
            if(a[i] % 2 == 0)
                sum++;
        }
        if(cont == 1 && (sum == n || sum == n - 2))
            printf("Yes\n");
        else
            printf("No\n");
    }
    return 0;
}
