//
// Created by 86178 on 2022/6/3.
//
#include "stdio.h"
#include<stdlib.h>
#include "iostream"
#define OK 1
#define ERROR 0
#define maxsize 20
const int N = 1e6+10;
using namespace std;
typedef struct{
    int key;
    float otherinfo;
}rcdtype;
typedef struct{
    rcdtype r[maxsize + 1];  //r[0]������Ϊ�ڱ�
    int length;
}sqlist;
//���������㷨
void insertsort(sqlist &L)
{
    int i,j;
    for( i = 2; i <= L.length;i++ )
    if (L.r[i].key < L.r[i-1].key)
    { L.r[0]=L.r[i];  // L.r[0]Ϊ������
        for ( j=i-1; L.r[0].key < L.r[j].key; --j){
            L.r[j+1]=L.r[j];}
        L.r[j+1]=L.r[0];
    }
}
//����
int Partition(sqlist &L, int low, int high)
{
    L.r[0] = L.r[low];
    int pivotkey = L.r[low].key;
    while (low < high)
    {
        while (low < high && L.r[high].key >= pivotkey) --high;
        L.r[low] = L.r[high];
        while (low < high && L.r[low].key <= pivotkey) ++low;
        L.r[high] = L.r[low];
    }
    L.r[low] = L.r[0];
    return low;
}

void Qsort(sqlist &L, int low, int high)
{
    if (low < high)
    {
        int pivotloc = Partition(L, low, high);
        Qsort(L, low, pivotloc-1);
        Qsort(L, pivotloc + 1, high);
    }
}

void Quicksort(sqlist &L)
{
    Qsort(L, 1, L.length);
}
//�鲢����
void Merge(rcdtype R[],rcdtype T[],int low, int mid ,int high)
{ //��������鲢
    int i=low,j=mid+1,k=low;
    while(i<=mid&&j<=high)
    {
        if(R[i].key<=R[j].key) T[k++]=R[i++];
        else T[k++] = R[j++];
    }
    while(i<=mid) T[k++] = R[i++];
    while(j<=mid) T[k++] = R[j++];
}
void MSort(rcdtype R[],rcdtype T[],int low,int high)
{
    int mid;
    rcdtype S[N];
    if(low==high) T[low]=R[low];
    else
    {
        mid = (low + high )/2;
        MSort(R,S,low,mid);
        MSort(R,S,mid+1,high);
        Merge(S,T,low,mid,high);
    }
}
void MergeSort(sqlist &L)
{
    MSort(L.r,L.r,1,L.length);
}
void Create_Sq(sqlist  &L)
{
    int n,i;
    cout << "���������ݸ�����������" << maxsize << "����" << endl;
    cin >> n;
    cout << ":���������������ݣ�\n";
    while (n > maxsize )
    {
        cout << "�������ޣ����ܳ���" << maxsize << "���������룺" << endl;
        cin >> n;
    }
    for (i = 1; i <= n; i ++)
    {
        cin >> L.r[i].key;
        L.r[i].otherinfo = i;
        L.length ++;
    }
}

void show(sqlist L)
{
    int i;
    for(i = 1;i <= L.length; i ++)
        cout << L.r[i].key << " ";
}
//��ԭ����
void save(sqlist &L)
{
    int m = L.length - 1, flag = 1;
    int j;
    while ((m > 0) && flag == 1)
    {
        flag = 0;     //��������û�з������� ��������ִ����һ��
        for (j = 1; j <= m; j ++)
        {
            if (L.r[j].otherinfo > L.r[j + 1].otherinfo)
            {
                flag = 1;
                rcdtype t = L.r[j];
                L.r[j] = L.r[j + 1];
                L.r[j + 1] = t;
            }
        }
        m --;
    }
}

int main()
{
    sqlist L;
    L.length = 0;
    Create_Sq(L);
    int i,j;
    printf("                    ����                            \n");
    printf("*******************************************************\n");
    printf("*                1-----ֱ�Ӳ���                        *\n");
    printf("*                2-----��������                        *\n");
    printf("*                3-----��ԭ����                        *\n");
    printf("*                4-----�˳�                            *\n");
    printf("*                5-----������                          *\n");
    printf("*                6-----�鲢����                          *\n");
    printf("\n");
    while(1)
    {
        cout<<"��ѡ��"<<endl;
        cin>>j;
        switch(j){
        case 1:
        insertsort(L);
        cout<<"ֱ�Ӳ��룺"<<endl;
        show(L);
        break;
        case 2:
        Quicksort(L);
        cout<<"��������"<<endl;
        show(L);
        break;
        case 3: save(L);
        cout<<"��ԭ���ݣ�"<<endl;
        show(L);
        break;
        case 4:
            exit (0);
        case 5:
                sqlist L1;
                L1.length = 0;
                Create_Sq(L1);
        case 6:
            int x;
            scanf("%d",&x);
           // MSort(L,L1,1,x);
            MergeSort(L1);
        }
    }
    return 0;
}