public class HelloWorldTwo {
	public static void main(String[] args){
		Student s1 = new Student();
		s1.name = "2113042015 �̳���";
		System.out.println(s1.name  + "˵ HelloWorld,Two");
		}
	}
class Student{
	String name;
}

