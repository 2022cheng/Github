public class Form {
    public static void main(String[] args) {
        int left[] = new int[]{0,1,2,3,4,5,6,7,8,9};
        int right[] = new int[]{0,1,2,3,4,5,6,7,8,9};

        for(int i = 0; i < left.length; i++){
            for (int j = 0; j < right.length; j++){
                System.out.print("(" + left[i] + "," + right[j] + ")");
            }
            System.out.println();
        }
    }
}
