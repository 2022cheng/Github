import java.util.Scanner;

public class Sort {
    public static void main(String[] args) {
        int num[] = new int[10];
        System.out.println("����10����");

        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < num.length; i++) {
            num[i] = sc.nextInt();
        }
        quick_sort(num);
        for(int i = 0; i < num.length; i++){
            System.out.print(num[i] + " ");
        }

    }
    //ð������
    public static void quick_sort(int num[]){

        int temp = 0;
        for(int i = 0; i < num.length; i++ ){
            for (int j = 0; j < num.length - i - 1; j++){
                if(num[j] > num[j + 1]){
                    temp = num[j];
                    num[j] = num[j + 1];
                    num[j + 1] = temp;
                }
            }
        }
    }
}

