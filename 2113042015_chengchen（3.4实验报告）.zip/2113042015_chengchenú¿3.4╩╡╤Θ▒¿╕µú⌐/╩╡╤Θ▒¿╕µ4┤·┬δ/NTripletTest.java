import java.util.Arrays;
import java.util.Scanner;

public class NTripletTest {
    public static void main(String[] args) {

        Tuple tuple = new Tuple();
        //����nԪ��
        tuple.initNTriplet();
        //���nԪ��
        tuple.outPutNTriplet();
        //����ֵ
        tuple.getMaxMinNumber();
    }
}
class Tuple{
    int n,m =100;
    float e[] = new float[m];

    //����nԪ��
    public void initNTriplet(){
        Scanner sc = new Scanner(System.in);
        System.out.println("������Ҫ������Ԫ��");
        n = sc.nextInt();
        System.out.printf("����%dԪ��\n",n);
        for (int i = 0; i < n; i++) {
            e[i] = sc.nextFloat();
        }
    }
    //���nԪ��
    public void outPutNTriplet() {
        System.out.print("[ ");
        for (int i = 0; i < n; i++) {
            System.out.print(e[i] + "  ");
        }
        System.out.println("]");

    }
    //��nԪ����ֵ
    public void getMaxMinNumber(){
        Arrays.sort(e);
        System.out.println("���ֵ");
        System.out.println(e[m - 1]);
        System.out.println("��Сֵ");
        System.out.println(e[m - n]);
    }
}

